
##Charger la library
library(haven)

##Importation de deux bases EDS 
data_enfant <- read_dta("C:/Formation ISE/ISE 1/Logiciel R/DIALLO_AissatouSega_TP1/Bases/Enfant.dta")
data_femme <- read_dta("C:/Formation ISE/ISE 1/Logiciel R/DIALLO_AissatouSega_TP1/Bases/Femme.dta")

##Structure des données
str(data_femme) #Nous avons pour cette base 3365 observations 
str(data_enfant) #Nous avons 10498 observations dans cette base

