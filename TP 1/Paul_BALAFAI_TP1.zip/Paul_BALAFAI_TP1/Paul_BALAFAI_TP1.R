#importation de la base sur l'insecurite alimentaire
df_insec_al <- read.csv('s08a_me_sen2021.csv')

#structure de la base insecurite alimentaire
str(df_insec_al)

#importation de la base ehcvm conso
df_conso <- read.csv('ehcvm_conso_sen2021.csv')

#structure de la base ehcvm conso
str(df_conso)

#importation de la base ehcvm menage
df_menage <- read.csv('ehcvm_menage_sen2021.csv')

#structure de la base ehcvm menage
str(df_menage)
