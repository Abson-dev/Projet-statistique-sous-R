
# Pour page large


# <!---BLOCK_LANDSCAPE_START--->
  
  
# <!---BLOCK_LANDSCAPE_STOP--->


# Pour mettre deux colonnes 

# <!---BLOCK_MULTICOL_START--->

# `r run_columnbreak()`

# <!---BLOCK_MULTICOL_STOP{widths: [3,3], space: 0.2, sep: true}--->